/*globals document, window, $ */
(function () {
  "use strict";

  var films = [];

  var TEMPLATE = "";

  // Flms: https://api.themoviedb.org/3/discover/movie?api_key=2e83cf763cae99f3a4b1d282402e63cb
  // Genres: https://api.themoviedb.org/3/genre/movie/list?api_key=2e83cf763cae99f3a4b1d282402e63cb&language=en-US
  $.getJSON("./db/movies.json", function (data) {
    // your code here ...
  });

  document.filtersForm.year.addEventListener("change", function () {
    // your code here ...
  });

  function displayFilms(list) {
    var collection = document.querySelector("#collection");

    // creating a dummy list for the first part of the task, after that it shall be removed
    list = [1, 2, 3, 4, 5];

    list.forEach(function (film) {
      // your code here ...
    });
  }

  window.addEventListener("scroll", function () {
    if (document.body.scrollTop > 200) {
      // your code here
    }
    else {
      // your code here
    }
  });
})();
